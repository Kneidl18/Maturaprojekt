#include <stdtypes.h>



#pragma DATA_SEG _DATA_ZEROPAGE    
    extern Byte       	RealTimeFlag;  
    extern Byte        	RealTimeCounter;    
    extern Byte 	RunLedCounter;
    extern	unsigned int	AirTemp;
    
    extern Byte AirDelay;
    extern Byte AirTempCelsius;
    extern Byte AirTempViertelGrad;