#include <hidef.h>          /* for EnableInterrupts macro */
#include "derivative.h"
#include "MC9S08AW32.h"


/* MAKRO BEFEHLE */
#define Nop()               __asm nop



